glasssquidApp
    .config([
        '$stateProvider',
        '$urlRouterProvider',
        function ($stateProvider, $urlRouterProvider) {
            // Use $urlRouterProvider to configure any redirects (when) and invalid urls (otherwise).
            $urlRouterProvider
                .otherwise('/login');

            $stateProvider
                .state("error", {
                    url: "/error",
                    templateUrl: 'app/views/error.html'
                })
                .state("error.404", {
                    url: "/404",
                    templateUrl: 'app/components/pages/error_404View.html'
                })
                .state("error.500", {
                    url: "/500",
                    templateUrl: 'app/components/pages/error_500View.html'
                })
                .state("restricted", {
                    abstract: true,
                    url: "",
                    views: {
                        'main_header': {
                            templateUrl: 'app/shared/header/candidate-header-view.html'
                        },
                        'main_footer': {
                            templateUrl: 'app/shared/footer/footer-view.html'
                        },
                        '': {
                            templateUrl: 'app/views/restricted.html'
                        }
                    },
                    resolve: {
                        deps: ['$ocLazyLoad', function ($ocLazyLoad) {
                            return $ocLazyLoad.load([], {serie: true});
                        }]
                    }
                })
                .state("restricted.candidate", {
                    abstract: true,
                    url: "/candidate",
                    templateUrl: 'app/components/candidate/candidate-view.html',
                    resolve: {
                        deps: ['$ocLazyLoad', function ($ocLazyLoad) {
                            return $ocLazyLoad.load([
                                'assets/css/candidate/custom.css'
                            ], {serie: true});
                        }],
                    }
                })
                .state("restricted.login", {
                    url: "/login",
                    templateUrl: 'app/shared/login/login-view.html',
                    resolve: {
                        deps: ['$ocLazyLoad', function ($ocLazyLoad) {
                            return $ocLazyLoad.load([], {serie: true});
                        }],
                    },
                    data: {
                        pageTitle: 'Login'
                    }

                })
                .state("restricted.candidate.dashboard", {
                    url: "/dashboard",
                    templateUrl: 'app/components/candidate/dashboard/dashboard-view.html',
                    controller: 'dashboardCtrl',
                    resolve: {
                        deps: ['$ocLazyLoad', function ($ocLazyLoad) {
                            return $ocLazyLoad.load([
                                'app/components/candidate/dashboard/dashboardController.js'
                            ], {serie: true});
                        }],
                    },
                    auth: {
                        loginRequired: true,
                        role: 'CANDIDATE'
                    },
                    data: {
                        pageTitle: 'Dashboard'
                    }

                })
                .state("restricted.candidate.video", {
                    url: "/record-video",
                    templateUrl: 'app/components/candidate/video-profile/video-view.html',
                    controller: 'videoRecordController',
                    resolve: {
                        deps: ['$ocLazyLoad', function ($ocLazyLoad) {
                            return $ocLazyLoad.load([
                                'app/components/candidate/video-profile/videoRecordController.js',
                                /*'assets/js/video-recorder/jquery.form.min.js',
                                 'assets/js/video-recorder/recordWebcamMain.js'*/
                            ], {serie: true});
                        }],
                    },
                    data: {
                        pageTitle: "Video Recorder"
                    }
                });
        }]);
