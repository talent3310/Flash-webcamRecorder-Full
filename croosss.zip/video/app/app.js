/*
 *  Glasssquid App AngularJS
 */

;"use strict";

var glasssquidApp = angular.module('glasssquidApp', [
    'ui.router',
    'oc.lazyLoad',
    'ngMaterial',
    'ngMessages',
    'base64',
    'ui.mask',
    'blockUI',
    'ngStorage',
    'ui-notification',
    'am.date-picker',
    'ui.knob',
    'rzModule',
    'angAccordion',
    'socialLogin',
    'SlideViewer',
    'jkAngularRatingStars'
]);

/* Run Block */
glasssquidApp
    .run([
        '$rootScope',
        '$state',
        '$stateParams',
        '$http',
        '$window',
        '$timeout',
        '$transitions',
        '$location',
        'webService',
        function ($rootScope, $state, $stateParams, $http, $window, $timeout, $transitions, $location, webService) {
            $rootScope.$state = $state;
            $rootScope.$stateParams = $stateParams;
            var flag = true;
            //prevent browser back button if user login.
            window.addEventListener('popstate', function (event) {
                if ($window.localStorage.user && flag && $state.is('restricted.candidate.dashboard')) {
                    history.pushState(null, null, '/candidate/dashboard');
                    flag = false;
                } else if ($state.is('restricted.login')) {
                    $rootScope.isUserLogin = false;
                }
            }, false);
            function storageChange(event) {
                console.log(event);
                if (event.key === 'user') {
                    window.location.reload();
                }
            }

            window.addEventListener('storage', storageChange, false);
            $transitions.onStart({
                to: function (state) {
                    window.scrollTo(0, 0);
                    if (state.auth != null && $window.localStorage.role != state.auth.role && $window.localStorage.user) {
                        if ($window.localStorage.role == 'CANDIDATE') {
                            $state.go("restricted.candidate.dashboard");
                        } else if ($window.localStorage.role == 'CLIENT') {
                            $state.go("clientStructure.client.dashboard");
                        } else if ($window.localStorage.role == 'VENDOR') {
                            $state.go("vendorStructure.vendor.dashboard");
                        }
                    }
                    if ($window.localStorage.user && (state.name == 'restricted.login' || state.name == 'restricted.candidate.signup')) {
                        $rootScope.isUserLogin = true;
                        $rootScope.candidateName = (webService.getLocalStorage('userName')) ? webService.getLocalStorage('userName') : 'Steve';
                        $rootScope.candidateEmail = webService.getLocalStorage('user');
                        $state.go("restricted.candidate.dashboard");
                    }
                    return state.auth != null && state.auth.loginRequired === true;
                }
            }, function (state) {
                if (!$window.localStorage.user) {
                    return $state.target("restricted.login");
                } else if ($window.localStorage.user) {

                }
            });

            /**
             * Remove selected skill when user refresh page.
             */
            window.localStorage.removeItem('selectedSkills');

            /**
             * Get the userAgent and userIP (https://l2.io/ip.js)
             */
            $rootScope.userAgent = $window.navigator.userAgent;
            $rootScope.userIP = userIP;
        }
    ])
    .config(["socialProvider", "$httpProvider", "$base64", function (socialProvider, $httpProvider, $base64) {
        socialProvider.setLinkedInKey("773ifnxc76llgu");

        var credentialsEncoded = $base64.encode('glasssquiduser:Fw#e1r2tdgYD$vd!w');
        $httpProvider.defaults.headers.common['Authorization'] = 'Basic ' + credentialsEncoded;
        $httpProvider.defaults.withCredentials = true;
    }]);