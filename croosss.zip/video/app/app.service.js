// glasssquidApp service
glasssquidApp
    .service('webService', ['$http', '$window', 'GS_SERVICE_URL', function ($http, $window, GS_SERVICE_URL) {
        this.invokeService = function (service, data, onsuccess, onerror) {
            console.log('invokeService::Entry');
            baseUrl = "https://beta.pomato.com/race-service/jDsa12EWRE46WhdasEJW99Rhdiu6aLshdEWTu52sOai/raceservice/";
            console.log(service);
            console.log(data);
            var serializedData = $.param(data);
            $http({
                method: 'POST',
                url: baseUrl + service,
                data: serializedData,
                withCredentials: true,
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            }).then(function successCallback(response) {
                onsuccess(response);
            }, function errorCallback(response) {
                onerror(response);
            });
        };

        this.invokeServiceWithUpload = function (service, data, onsuccess, onerror) {
            console.log('invokeService::Entry');
            baseUrl = "https://beta.pomato.com/race-service/jDsa12EWRE46WhdasEJW99Rhdiu6aLshdEWTu52sOai/raceservice/";
            console.log(service);
            console.log(data);
            $http({
                method: 'POST',
                url: baseUrl + service,
                data: data,
                withCredentials: true,
                headers: {
                    'Content-Type': undefined
                },
                transformRequest: angular.identity
            }).then(function successCallback(response) {
                onsuccess();
            }, function errorCallback(response) {
                onerror();
            });
        };

        this.invokeAWSService = function (url, data, onsuccess, onerror) {
            console.log('invokeService::Entry');
            console.log(data);
            var serializedData = $.param(data);
            $http({
                method: 'POST',
                url: url,
                data: serializedData,
                withCredentials: false,
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            }).then(function successCallback(response) {
                onsuccess(response);
            }, function errorCallback(response) {
                onerror(response);
            });
        };

        /**
         * Request for Login.
         * @param data
         * @param onsuccess
         * @param onerror
         */
        this.requestLogin = function (data, onSuccess, onError) {
            data = {'lamdaFunction': 'glasssquidLogin', 'payLoad': data};
            var serializedData = $.param(data);
            $http({
                method: 'POST',
                url: GS_SERVICE_URL,
                data: serializedData,
                withCredentials: true,
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            }).then(function successCallback(response) {
                try {
                    data = JSON.parse(response.data);
                    console.log(data);
                    if (typeof data.CANDIDATE_EMAIL != 'undefined' && data.CANDIDATE_EMAIL != '') {
                        $window.localStorage.user = data.CANDIDATE_EMAIL;
                    }
                    if (typeof data.CANDIDATE_FIRST_NAME != 'undefined' && data.CANDIDATE_FIRST_NAME != '') {
                        $window.localStorage.userName = data.CANDIDATE_FIRST_NAME;
                    }
                    if (typeof data.ROLE != 'undefined' && data.ROLE != '') {
                        $window.localStorage.role = data.ROLE;
                    }
                }
                catch (e) {
                    //TODO: Do nothing!!
                }
                onSuccess(response);
            }, function errorCallback(err) {
                onError(err);
            });
        };

        /**
         * Get profile image from API.
         * @param string imageType imageType should be 'T' for thumbnail or 'F' for Full image.
         * @param success callback
         * @param error callback
         * @returns {boolean}
         */
        this.getProfileImage = function (imageType, success, error) {
            if (imageType == 'T' || imageType == 'F') {
                payLoad = {
                    'role': this.getLocalStorage('role'),
                    'id': this.getUser(),
                    'imageSize': imageType
                };
                this.sendPostRequest('getCandidateProfileImage', payLoad, function (response) {
                    success(response);
                }, function (err) {
                    error(err);
                });
            } else {
                return false;
            }
        };

        /**
         * Check if user is login or not.
         * @returns {boolean}
         */
        this.isLogin = function () {
            user = $window.localStorage.user;
            if (typeof user == 'undefined' || user == null || user == '') {
                return false;
            }
            return true;
        }

        /**
         * Get user information from session.
         * @param user
         * @returns {*}
         */
        this.getUser = function () {
            user = $window.localStorage.user;
            if (typeof user == 'undefined' || user == null || user == '') {
                return false;
            }
            return user;
        }

        /**
         * Get user information from session.
         * @param user
         * @returns {*}
         */
        this.getUserName = function () {
            user = $window.localStorage.userName;
            if (typeof user == 'undefined' || user == null || user == '') {
                return false;
            }
            return user;
        }

        /**
         * Set user email in session.
         * @param user
         */
        this.setUser = function (userEmail, userName) {
            $window.localStorage.user = userEmail;
            if (typeof userName != 'undefined') {
                $window.localStorage.userName = userName;
            }
        }

        /**
         * Logout user
         * @param url
         */
        this.logOut = function () {
            // alert();
            $window.localStorage.user = "";

            $window.localStorage.clear();

        }

        /**
         * Send Post request to given Service URL
         * @param serviceUrl
         * @param data
         * @param onSuccess
         * @param onError
         */
        this.sendPostRequest = function (lamdaFunction, payLoad, onSuccess, onError) {
            data = {
                'lamdaFunction': lamdaFunction,
                'payLoad': JSON.stringify(payLoad)
            };
            $http({
                method: 'POST',
                url: GS_SERVICE_URL,
                data: $.param(data),
                withCredentials: true,
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            })
                .then(function successCallback(response) {
                    onSuccess(response);
                }, function errorCallback(err) {
                    onError(err);
                });
        };

        /**
         * Upload Resume file on Server.
         * @param data
         * @param uploadUrl
         * @param onSuccess
         * @param onError
         */
        this.uploadFileToUrl = function (data, uploadUrl, onSuccess, onError) {
            var fd = new FormData();
            fd.append('resumefile', data.resumefile);
            fd.append('emailId', data.email);

            $http.post(uploadUrl, fd, {
                transformRequest: angular.identity,
                headers: {'Content-Type': undefined}
            }).then(function successCallback(response) {
                onSuccess(response);
                console.log('success');
            }, function errorCallback(err) {
                onError(err);
                console.log('error');
            });
        }

        /**
         * Set Local Storage
         * @param name
         * @param value
         */
        this.setLocalStorage = function (name, value) {
            $window.localStorage.setItem(name, value);
        };

        /**
         * Get Local Storage
         * @param name
         * @returns {boolean}
         */
        this.getLocalStorage = function (name) {
            var local = $window.localStorage.getItem(name);
            if (typeof local == 'undefined' || local == null || local == '') {
                return false;
            }
            return local;
        };

        /**
         * Clear Local Storage
         * @param name
         */
        this.clearLocalStorage = function (name) {
            $window.localStorage.name = '';
        };

        this.detectMicrosoftBrowsers = function () {
            var ua = window.navigator.userAgent;
            var version = false;
            var msie = ua.indexOf('MSIE ');
            if (msie > 0) {
                // IE 10 or older => return version number
                version = parseInt(ua.substring(msie + 5, ua.indexOf('.', msie)), 10);
            }

            var trident = ua.indexOf('Trident/');
            if (trident > 0) {
                // IE 11 => return version number
                var rv = ua.indexOf('rv:');
                version = parseInt(ua.substring(rv + 3, ua.indexOf('.', rv)), 10);
            }

            var edge = ua.indexOf('Edge/');
            if (edge > 0) {
                // Edge (IE 12+) => return version number
                version = parseInt(ua.substring(edge + 5, ua.indexOf('.', edge)), 10);
            }

            if (version === false) {
                return 'others';
            } else if (version >= 12) {
                return 'edge';
            } else {
                return 'ie';
            }
        };
    }])
    .service('alertService', ['$mdDialog', '$window', 'Notification', function ($mdDialog, $window, Notification) {
        /**
         * Show Alert popup.
         * @param title
         * @param text
         */
        this.showAlert = function (title, text) {
            $mdDialog.show(
                $mdDialog.alert()
                    .parent(angular.element(document.querySelector('body')))
                    .clickOutsideToClose(true)
                    .title(title)
                    .textContent(text)
                    .ariaLabel('Alert')
                    .ok('Okay')
            );
        };

        /**
         * Set Notification message in session.
         * @param message String
         * @param type String Possible values are : success|failure|warning
         * @returns {boolean}
         */
        this.setNotification = function (message, type) {
            if (typeof message == 'undefined' || message == '' || message == null) {
                return false;
            }
            if (typeof type == 'undefined' || type == '' || type == null) {
                type = 'success';
            }
            $window.localStorage.setItem('alertMessage', message);
            $window.localStorage.setItem('alertType', type);
        }

        /**
         * Get Notification message to display on screen.
         * @returns {{message, type}}
         */
        this.getNotification = function () {
            var message = $window.localStorage.getItem('alertMessage');
            var type = $window.localStorage.getItem('alertType');
            if (typeof message == 'undefined' || message == null || message == '') {
                message = false;
            }
            $window.localStorage.setItem('alertMessage', '');
            $window.localStorage.setItem('alertType', '');
            return {message: message, type: type};
        }

        /**
         * Clear Notification message from session.
         */
        this.clearNotification = function () {
            $window.localStorage.setItem('alertMessage', '');
            $window.localStorage.setItem('alertType', '');
        };

        /**
         * Show Notification Message on screen
         */
        this.showNotification = function () {
            var flashMessage = this.getNotification();
            if (flashMessage.message) {
                if (flashMessage.type == 'success') {
                    Notification.success({message: flashMessage.message, delay: 3000});
                } else if (flashMessage.type == 'failure') {
                    Notification.error({message: flashMessage.message, delay: null});
                } else if (flashMessage.type == 'warning') {
                    Notification.warning({message: flashMessage.message, delay: null});
                }
            }
        };
    }])
    .service('Service', ['$http', '$localStorage', '$window', function ($http, $localStorage, $window) {
        this.invokeService = function (service, data, onsuccess, onerror) {
            console.log('invokeService::Entry');
            baseUrl = "https://beta.pomato.com/race-service/jDsa12EWRE46WhdasEJW99Rhdiu6aLshdEWTu52sOai/raceservice/";
            console.log(service);
            console.log(data);
            var serializedData = $.param(data);
            $http({
                method: 'POST',
                url: baseUrl + service,
                data: serializedData,
                withCredentials: true,
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            }).then(function successCallback(response) {
                onsuccess();
            }, function errorCallback(response) {
                onerror();
            });
        };

        this.invokeServiceWithUpload = function (service, data, onsuccess, onerror) {
            console.log('invokeService::Entry');
            baseUrl = "https://beta.pomato.com/race-service/jDsa12EWRE46WhdasEJW99Rhdiu6aLshdEWTu52sOai/raceservice/";
            console.log(service);
            console.log(data);
            $http({
                method: 'POST',
                url: baseUrl + service,
                data: data,
                withCredentials: true,
                headers: {
                    'Content-Type': undefined
                },
                transformRequest: angular.identity
            }).then(function successCallback(response) {
                onsuccess();
            }, function errorCallback(response) {
                onerror();
            });
        };

        /**
         * Request for Login.
         * @param data
         * @param onsuccess
         * @param onerror
         */
        this.requestLogin = function (data, onsuccess, onerror) {
            // original
            // serviceUrl = "https://iz0ib7fh49.execute-api.us-east-1.amazonaws.com/stage/candidate";

            $http({
                method: 'POST',
                url: GS_SERVICE_URL,
                data: data,
                withCredentials: true,
                headers: {
                    'Content-Type': 'application/json'
                }
            }).then(function successCallback(response) {
                try {
                    $window.localStorage.user = (JSON.parse(response.data)).EMPLOYER_EMAIL;
                }
                catch (e) {
                    // do nothing!!
                }
                onsuccess(response);
            }, function errorCallback(response) {
                onerror(response);
            });
        };

        /**
         * Add candidate for employer.
         * @param data
         * @param onsuccess
         * @param onerror
         */
        this.addEmployerCandidate = function (data, onsuccess, onerror) {
            serviceUrl = "https://mfcmfw0kgf.execute-api.us-east-1.amazonaws.com/stage/candidate";
            $http({
                method: 'POST',
                url: serviceUrl,
                data: data,
                withCredentials: false,
                headers: {
                    'Content-Type': 'application/json'
                }
            }).then(function successCallback(response) {
                onsuccess(response);
            }, function errorCallback(response) {
                onerror(response);
            });
        };

        /**
         * Make request for signup.
         * @param data
         * @param onsuccess
         * @param onerror
         */
        this.requestSignup = function (data, onsuccess, onerror) {
            serviceUrl = "https://3pj5sa8vyh.execute-api.us-east-1.amazonaws.com/stage/candidate";
            $http({
                method: 'POST',
                url: serviceUrl,
                data: data,
                withCredentials: false,
                headers: {
                    'Content-Type': 'application/json'
                }
            }).then(function successCallback(response) {
                onsuccess(response);
            }, function errorCallback(response) {
                onerror(response);
            });
        };

        /**
         * Set user information in session.
         * @param resp
         */
        this.setUser = function (usr) {
            $window.localStorage.user = usr;
        }

        /**
         * Check if user is login or not.
         * @returns {boolean}
         */
        this.isLogin = function () {
            user = $window.localStorage.user;
            if (typeof user == 'undefined' || user == null || user == '') {
                return false;
            }
            return true;
        }

        /**
         * Get user information from session.
         * @param user
         * @returns {*}
         */
        this.getUser = function (user) {
            user = $window.localStorage.user;
            if (typeof user == 'undefined' || user == null || user == '') {
                return false;
            }
            return user;
        }


        /**
         * Make post request to given utl.
         * @param service
         * @param data
         * @param onsuccess
         * @param onerror
         */
        this.sendData = function (service, data, onsuccess, onerror) {
            baseUrl = "https://beta.pomato.com/race-service/jDsa12EWRE46WhdasEJW99Rhdiu6aLshdEWTu52sOai/raceservice/";
            $http({
                method: 'POST',
                url: baseUrl + service,
                data: data,
                withCredentials: true,
                headers: {
                    'Content-Type': undefined
                },
                transformRequest: angular.identity
            }).then(function successCallback(response) {
                onsuccess();
            }, function errorCallback(response) {
                onerror();
            });
        };

        /**
         * Make get request to given url.
         * @param service
         * @param data
         * @param onsuccess
         * @param onerror
         */
        this.getData = function (service, data, onsuccess, onerror) {
            baseUrl = "https://beta.pomato.com/race-service/jDsa12EWRE46WhdasEJW99Rhdiu6aLshdEWTu52sOai/raceservice/";
            $http({
                method: 'GET',
                url: baseUrl + service,
                //data: data,
                withCredentials: true,
                headers: {
                    'Content-Type': undefined
                },
                transformRequest: angular.identity
            }).then(function successCallback(response) {
                onsuccess(response);
            }, function errorCallback(err) {
                onerror(err);
            });
        };


        /**
         * Get all the candidates for a given employer
         * @param data
         * @param onsuccess
         * @param onerror
         */
        this.getCandidatesByEmployer = function (data, onsuccess, onerror) {
            serviceUrl = "https://ardd1c5dic.execute-api.us-east-1.amazonaws.com/stage/candidate";
            $http({
                method: 'POST',
                url: serviceUrl,
                data: data,
                withCredentials: false,
                headers: {
                    'Content-Type': 'application/json'
                }
            }).then(function successCallback(response) {
                onsuccess(response);
            }, function errorCallback(response) {
                onerror(response);
            });
        };


        /**
         * Disassociate Candidate from an Employer
         * @param data
         * @param onsuccess
         * @param onerror
         */
        this.deleteEmployerCandidate = function (data, onsuccess, onerror) {
            serviceUrl = "https://itnewqnl8h.execute-api.us-east-1.amazonaws.com/stage/candidate";
            $http({
                method: 'POST',
                url: serviceUrl,
                data: data,
                withCredentials: false,
                headers: {
                    'Content-Type': 'application/json'
                }
            }).then(function successCallback(response) {
                onsuccess(response);
            }, function errorCallback(response) {
                onerror(response);
            });
        };
    }]);
