/* ocLazyLoad config */

glasssquidApp
    .config([
        '$ocLazyLoadProvider',
        function ($ocLazyLoadProvider) {
            $ocLazyLoadProvider.config({
                debug: false,
                events: false,
                modules: [
                    // ----------- FORM ELEMENTS -----------
                    {
                        name: 'for_dashboard',
                        files: [
                            'app/components/candidate/dashboard/dashboardController.js'
                        ],
                        serie: true
                    }
                ]
            })
        }
    ]);