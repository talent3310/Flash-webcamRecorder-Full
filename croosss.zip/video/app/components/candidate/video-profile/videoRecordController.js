angular.module('glasssquidApp')
    .controller('videoRecordController', function ($scope, $state, webService, alertService) {
        $scope.startRecording = function () {
            /**
             * Action perform in assets/js/video-recorder/webrtcCamMain.js
             */
        };
        $scope.pauseRecording = function () {
            /**
             * Action perform in assets/js/video-recorder/webrtcCamMain.js
             */
        };
        $scope.resumeRecording = function () {
            /**
             * Action perform in assets/js/video-recorder/webrtcCamMain.js
             */
        };
        $scope.stopRecording = function () {
            /**
             * Action perform in assets/js/video-recorder/webrtcCamMain.js
             */
        };
        $scope.uploadRecording = function () {
            /**
             * Action perform in assets/js/video-recorder/webrtcCamMain.js
             */
        };
    });