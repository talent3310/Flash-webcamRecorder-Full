angular
    .module('glasssquidApp')
    .controller('dashboardCtrl', [
        '$rootScope',
        '$scope',
        'alertService',
        '$timeout',
        function ($rootScope, $scope, alertService,$timeout) {
             $timeout(function () {
                window.scrollTo(0, 0);
            }, 500);
        }]);