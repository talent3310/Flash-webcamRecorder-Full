/*
 *  Glasssquid App angularjs
 *  controller
 */

angular
    .module('glasssquidApp')
    .controller('mainCtrl', [
        '$scope',
        '$rootScope',
        function ($scope, $rootScope) {
        }
    ]);
angular.module('glasssquidApp')
    .controller('userRegistrationController', ['$state', '$stateParams', '$rootScope', '$scope', '$location', '$anchorScroll', 'webService', 'focus', 'alertService', '$window', '$mdDialog', 'Notification', function ($state, $stateParams, $rootScope, $scope, $location, $anchorScroll, webService, focus, alertService, $window, $mdDialog, Notification) {
        $scope.tmpLocation = '';
        $scope.user = {
            emailId: "",
            password: ""
        };

        /**
         * GET FORM LOCALSTORAGE FOR HEADER COMPONENT
         */
        $rootScope.isUserLogin = webService.isLogin();
        $rootScope.candidateName = (webService.getLocalStorage('userName')) ? webService.getLocalStorage('userName') : 'Steve';
        if (webService.getLocalStorage('userPhoto')) {
            $rootScope.profileImage = webService.getLocalStorage('userPhoto');
        } else {
            $rootScope.profileImage = 'assets/images/default-user.png';
        }
        $rootScope.candidateEmail = webService.getLocalStorage('user');

        /**
         * Make login request.
         */
        $scope.login = function () {
            if (typeof $scope.user.emailId == 'undefined' || $scope.user.emailId == '' || $scope.user.emailId == null) {
                webService.setNotification('Please enter Email.', 'failure');
                $scope.showNotification();
            } else if (typeof $scope.user.password == 'undefined' || $scope.user.password == '' || $scope.user.password == null) {
                webService.setNotification('Please enter Password.', 'failure');
                $scope.showNotification();
            } else {
                webService.setLocalStorage('user', 'test@gmail.com');
                webService.setLocalStorage('userName', 'Steve');
                webService.setLocalStorage('role', 'CANDIDATE');
                $state.go('restricted.candidate.dashboard', {location: 'replace'});
            }
        }

        /**
         * Allow user to logout.
         */
        $scope.logoutMe = function () {
            webService.logOut();
            $rootScope.isUserLogin = webService.isLogin();
            $rootScope.profileImage = 'assets/images/default-user.png';
            $(".navigationbar__navigation").hide();//This is Quick fix. have too find alternative for that to close menu after click on logout menu.
            $state.go('restricted.login', {location: 'replace'});
        }
    }]);
