 function captureUserMedia(mediaConstraints, successCallback, errorCallback) {
     navigator.mediaDevices.getUserMedia(mediaConstraints).then(successCallback).catch(errorCallback);
 }
 var mediaConstraints = {
     audio: !IsOpera && !IsEdge, // record both audio/video in Firefox/Chrome
     video: true
 };
 var recordVideo;
 var blob;
 $(document).ready(function() {
     $('#webrtc_processing').hide();
     $('#webrtc_save').hide();
     $("#webrtcVideo").removeAttr("controls");
     $("#recPrnt").hide();
 });
 document.querySelector('#start-recording').onclick = function() {
     setTimeout(function() { $("#recPrnt").show(); }, 1000);
     this.disabled = true;
     document.getElementById('save-recording').disabled = true;
     captureUserMedia(mediaConstraints, onMediaSuccess, onMediaError);

 };
 document.querySelector('#stop-recording').onclick = function() {
     $("#recPrnt").hide();
     this.disabled = true;
     document.querySelector('#resume-recording').disabled = true;
     $('#webrtc_processing').show();

     recordVideo.stopRecording(function() {
         document.querySelector('#start-recording').disabled = false;
         document.getElementById('save-recording').disabled = false;
         blob = this.getBlob();
         var videoPreview = document.getElementById('webrtcVideo');
         videoPreview.src = window.URL.createObjectURL(blob);
         $('#webrtc_processing').hide();
         $("#webrtcVideo").attr("controls", true);
     });

     document.querySelector('#pause-recording').disabled = true;

 };
 document.querySelector('#pause-recording').onclick = function() {
     recordVideo.pauseRecording(); // pause the recording

     $("#recPrnt").hide();
     this.disabled = true;

     document.querySelector('#resume-recording').disabled = false;
 };
 document.querySelector('#resume-recording').onclick = function() {
     $("#recPrnt").show();
     this.disabled = true;

     recordVideo.resumeRecording();
     document.querySelector('#pause-recording').disabled = false;
     document.getElementById("webrtcVideo").currentTime = 5;

 };
 document.querySelector('#save-recording').onclick = function() {
     this.disabled = true;

     $('#webrtc_save').show();
     document.querySelector('#start-recording').disabled = true;
     uploadToServerRecordedFile(blob, function() {
        $('#webrtc_save').hide();
         alert('saved');
     })
 };


 function onMediaSuccess(stream) {
     var videoPreview = document.getElementById('webrtcVideo');
     var videoFile = !!navigator.mozGetUserMedia ? 'video.gif' : 'video.webm';

     videoPreview.src = window.URL.createObjectURL(stream);
     videoPreview.play();
     recordVideo = RecordRTC(stream, {
         type: 'video',
         // recorderType: !!navigator.mozGetUserMedia ? MediaStreamRecorder : WhammyRecorder
     });
     recordVideo.startRecording();
     document.querySelector('#stop-recording').disabled = false;
     document.querySelector('#pause-recording').disabled = false;
 }

 function onMediaError(e) {
     console.error('media error', e);
 }
 var videosContainer = document.getElementById('webrtcCamContainer');
 var index = 1;


 window.onbeforeunload = function() {
     document.querySelector('#start-recording').disabled = false;
 };

 function uploadToServerRecordedFile(file, callback) {

     var fileType = 'video'; // or "audio"
     if (!file) {
         throw 'Blob object is required.';
     }

     if (!file.type) {
         try {
             file.type = 'video/webm';
         } catch (e) {}
     }
     var fileExtension = (file.type || 'video/webm').split('/')[1];
     var fileFullName = (Math.round(Math.random() * 9999999999) + 888888888) + '.' + fileExtension;
     var formData = new FormData();
     formData.append(fileType + '-filename', fileFullName);
     formData.append(fileType + '-blob', file);
     xhr('save.php', formData, function(fName) {
         callback();
     });

 }
