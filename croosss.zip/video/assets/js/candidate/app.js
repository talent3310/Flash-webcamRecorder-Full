
candidateAPP.run(['$anchorScroll', function ($anchorScroll) {
    $anchorScroll.yOffset = 50;   // always scroll by 50 extra pixels
}])
candidateAPP.run(['$anchorScroll', function ($anchorScroll) {
    $anchorScroll.yOffset = 50;   // always scroll by 50 extra pixels
}])

candidateAPP.config(["$httpProvider", "$base64", "$locationProvider", "amDatePickerConfigProvider", function ($httpProvider, $base64, $locationProvider, amDatePickerConfigProvider) {
    var credentialsEncoded = $base64.encode('raceuser:Fw#e1r2tdgYD$vd!w');
    $httpProvider.defaults.headers.common['Authorization'] = 'Basic ' + credentialsEncoded;
    $httpProvider.defaults.withCredentials = true;

    $locationProvider.html5Mode({
        enabled: true,
        requireBase: false
    });
    amDatePickerConfigProvider.setOptions({
        popupDateFormat: 'Do of MMMM',
        calendarIcon: '../images/cal-icon/ic_today_24px.svg',
        clearIcon: '../images/cal-icon/ic_close_24px.svg',
        nextIcon: '../images/cal-icon/ic_chevron_right_18px.svg',
        prevIcon: '../images/cal-icon/ic_chevron_left_18px.svg'
    })
}]);

candidateAPP.controller('userRegistrationController1', ['$rootScope', '$scope', '$location', '$anchorScroll', 'webService', 'focus', 'alertService', '$window', '$mdDialog', 'Notification', function ($rootScope, $scope, $location, $anchorScroll, webService, focus, alertService, $window, $mdDialog, Notification) {
    var host = $location.host();
    $scope.baseUrl = 'https://candidate.glasssquid.io/candidate/';
    if (host == 'localhost') {
        $scope.baseUrl = 'http://localhost/glasssquid_candidate/UI/candidate/';
    } else if (host == 'candidate.glasssquid.io.s3-website-us-east-1.amazonaws.com') {
        $scope.baseUrl = 'http://candidate.glasssquid.io.s3-website-us-east-1.amazonaws.com/';
    }

    /**
     * Show Notification Message on screen
     */
    $scope.showNotification = function () {
        var flashMessage = alertService.getNotification();
        if (flashMessage.message) {
            if (flashMessage.type == 'success') {
                Notification.success({message: flashMessage.message, delay: 3000});
            } else if (flashMessage.type == 'failure') {
                Notification.error({message: flashMessage.message, delay: null});
            } else if (flashMessage.type == 'warning') {
                Notification.warning({message: flashMessage.message, delay: null});
            }
        }
    };
    /**
     * End
     */

    $scope.showNotification();

    $scope.pageId = $location.search().page;

    $scope.editProfilePage1 = true;
    $scope.editProfilePage2 = false;
    $scope.editProfilePage3 = false;
    $scope.editProfilePage4 = false;

    $scope.profilePageIsDirty = false;
    $scope.jobPreferencePageIsDirty = false;
    $scope.socialPageIsDirty = false;

    var win = $window;
    $scope.$watch('profilePageIsDirty', function(value) {
        if(value) {
            win.onbeforeunload = function(){
                return 'All your changes will be lost. Are you sure you want to do this?';
            };
        }
    });
    $scope.$watch('jobPreferencePageIsDirty', function(value) {
        if(value) {
            win.onbeforeunload = function(){
                return 'All your changes will be lost. Are you sure you want to do this?';
            };
        }
    });

    /**
     * Check if page is dirty or not.
     * @param formName
     * @returns {*}
     */
    $scope.isDirty = function (formName) {
        if (formName == 'userRegForm') {
            return $scope.userRegForm.$dirty;
        } else if (formName == 'profile' && $scope.editProfilePage1) {
            return $scope.profilePageIsDirty;
        } else if (formName == 'candidateJobForm' && $scope.editProfilePage2) {
            if ($scope.candidateJobForm.$dirty) {
                return true;
            } else if ($scope.jobPreferencePageIsDirty) {
                return true;
            }
        } else if (formName == 'candidateSocialForm' && $scope.editProfilePage3) {
            return $scope.candidateSocialForm.$dirty;
        }
        return false;
    };

    /**
     * Show Profile page and hide other pages.
     */
    $scope.showProfilePage = function () {
        $scope.editProfilePage1 = true;
        $scope.editProfilePage2 = false;
        $scope.editProfilePage3 = false;
        $scope.editProfilePage4 = false;
    };

    /**
     * Show Job Preference page and hide other pages.
     */
    $scope.showJobPreferencePage = function () {
        $scope.editProfilePage1 = false;
        $scope.editProfilePage2 = true;
        $scope.editProfilePage3 = false;
        $scope.editProfilePage4 = false;
    };

    /**
     * Show Social Preference page and hide other pages.
     */
    $scope.showSocialPreferencePage = function () {
        $scope.editProfilePage1 = false;
        $scope.editProfilePage2 = false;
        $scope.editProfilePage3 = true;
        $scope.editProfilePage4 = false;
    };

    /**
     * Show Video Preference page and hide other pages.
     */
    $scope.showVideoPreferencePage = function () {
        $scope.editProfilePage1 = false;
        $scope.editProfilePage2 = false;
        $scope.editProfilePage3 = false;
        $scope.editProfilePage4 = true;
    };

    /**
     * Redirect user on deshbaord.
     */
    $scope.showDashboard = function () {
        $window.location.href = $scope.baseUrl + 'dashboard.html';
    };

    /**
     * Get all skills from API.
     */
    $scope.getAllSkills = function () {
        //var serviceUrl = "https://ojftezej29.execute-api.us-east-1.amazonaws.com/stage/candidate";
        lamdaFunction = "getJRSkills";
        var dummyData = {
            id: "",
            skill: ""
        };
        webService.sendPostRequest(
            lamdaFunction,
            dummyData,
            function (response) {
                data = response.data;
                $scope.allSkills = data.jrSkills;
            },
            function (error) {
                console.log(error);
            }
        );
    };

    /**
     * For Edit Profile
     */
    if (typeof $scope.pageId != 'undefined') {
        if ($scope.pageId == 'profile') {
            $scope.getAllSkills();
            $scope.showProfilePage();
        } else if ($scope.pageId == 'job_preferences') {
            $scope.showJobPreferencePage();
        } else if ($scope.pageId == 'preferences') {
            $scope.showSocialPreferencePage();
        }
    } else {
        if ($scope.editProfilePage1) {
            $scope.getAllSkills();
        }
    }

    $scope.allowedFileTypesForProfilePicture = ['image/x-png', 'image/png', 'image/jpeg', 'image/bmp'];
    $scope.fileName = '';
    $scope.mainProfileImage = $rootScope.profileImage = $scope.baseUrl + '../images/default-user.png';

    var preferredCommnChannels = [];
    var preferredEmploymentTypes = [];
    $scope.candidateEmail = '';
    $rootScope.candidateName = '';
    $rootScope.isUserLogin = webService.isLogin();
    $scope.showFilePopup = false;

    $scope.skills = [
        'JAVA',
        '.NET',
        'PYTHON'
    ];
    $scope.roles = [
        'Development',
        'Architecture',
        'Support',
        'Leadership',
        'Administration',
        'Testing',
        'System Administration'
    ];
    $scope.experiences = [
        '0-2',
        '3-7',
        '5-7',
        '7-9',
        '9-14',
        '15+'
    ];
    $scope.educations = [
        'GED',
        'High School',
        'Some College',
        'Bachelors',
        'Masters',
        'Doctorate'
    ];
    $scope.workAuthorizations = [
        'US Citizen',
        'Permanent Resident',
        'H1B',
        'E80',
        'TN Visa',
        'J1 Visa'
    ];
    $scope.contractTypes = [
        'W2',
        '1099',
        'Corp-to-Corp',
        'Contract-to-Hire'
    ];
    $scope.statuses = [
        'Actively Looking',
        'Passively Looking',
        'Not Looking'
    ];
    $scope.importance = [
        'Career Growth',
        'Telecommute',
        'Work life balance',
        'Travel'
    ];
    $scope.locations = [];
    $scope.radiusOptions = [
        '5 Miles',
        '10 Miles',
        '20 Miles',
        '30 Miles',
        '50 Miles',
        '75 Miles',
        '100+ Miles',
    ];
    $scope.projectDurationOptions = [
        {
            name: 'Please Select Project Duration.',
            value: -1
        },
        {
            name: '3 Months+',
            value: 3
        },
        {
            name: '6 Months+',
            value: 6
        },
        {
            name: '1 Year+',
            value: 12
        },
        {
            name: '2 Year+',
            value: 24
        }
    ];
    $scope.workOptions = [
        'Yes',
        'No',
        'Remote Only'
    ];
    $scope.tmpLocation = '';

    //Set all default values here.
    $scope.user = {
        skillMatchPercent: 100,
        hourRate: 50,
        projectDuration: -1,
        fbId: '',
        skypeId: '',
        snapchatId: '',
        githubId: '',
        linkedinId: '',
        stackoverflowId: '',
        isPreferredAlternateEmail: false,
        isPreferredPhone: false,
        isPreferredText: false,
        phone: '',
        alternateEmail: '',
        phoneNo: '',
        candidatetext: ''
    };

    $scope.allSkills = {};
    $scope.selectedSkills = [];
    $scope.selectedRoles = [];
    $scope.selectedExperiences = [];
    $scope.selectedEducations = [];
    $scope.selectedWorkAuthorization = [];
    $scope.selectedContractType = [];
    $scope.selectedStatus = [];
    $scope.selectedImportance = [];
    $scope.selectedWorkOptions = [];

    /**
     * Error Variables
     */
    $scope.jobMatchPercentThresholdError = false;
    $scope.minHourlyRateExpectedError = false;
    $scope.preferredContractTypeError = false;
    $scope.statusError = false;
    $scope.statusError = false;
    $scope.whatsImportantError = false;
    $scope.workAuthorizationError = false;
    $scope.workOptionError = false;
    $scope.locationExistError = false;
    /**
     * End
     */

    /**
     * Make API call to get detail for Edit
     */
    if (typeof $scope.pageId != 'undefined') {
        serviceUrl = 'https://r4n2r9ldpa.execute-api.us-east-1.amazonaws.com/stage/candidate';
        var data = {
            emailId: webService.getUser()
        };
        webService.sendPostRequest(serviceUrl, JSON.stringify(data),
            function (response) {
                data = JSON.parse(response.data);
                if (data.RESPONSE_CODE == 'SUCCESS') {
                    if (typeof data.candidatePref != 'undefined') {
                        data = data.candidatePref;
                        if ($scope.pageId == 'profile') {
                            if (typeof data.education != 'undefined' && data.education != '-') {
                                $scope.selectedEducations = data.education.split(",");
                            }
                            if (typeof data.yearsOfExp != 'undefined' && data.yearsOfExp != '-') {
                                $scope.selectedExperiences = data.yearsOfExp.split(",");
                            }
                            if (typeof data.coreSkills != 'undefined' && data.coreSkills != '-') {
                                $scope.selectedSkills = data.coreSkills;
                            }
                            if (typeof data.coreRoles != 'undefined' && data.coreRoles != '-') {
                                $scope.selectedRoles = data.coreRoles.split(",");
                            }
                        } else if ($scope.pageId == 'job_preferences') {
                            if (typeof data.jobMatchPercentThreshold != 'undefined' && data.jobMatchPercentThreshold != '-') {
                                $scope.user.skillMatchPercent = parseInt(data.jobMatchPercentThreshold);
                            }
                            if (typeof data.workAuthorization != 'undefined' && data.workAuthorization != '-') {
                                $scope.selectedWorkAuthorization = data.workAuthorization.split(",");
                            }
                            if (typeof data.preferredContractType != 'undefined' && data.preferredContractType != '-') {
                                $scope.selectedContractType = data.preferredContractType.split(",");
                            }
                            if (typeof data.candidateStatus != 'undefined' && data.candidateStatus != '-') {
                                $scope.selectedStatus = data.candidateStatus.split(",");
                            }
                            if (typeof data.minHourlyRateExpected != 'undefined' && data.minHourlyRateExpected != '-') {
                                $scope.user.hourRate = parseInt(data.minHourlyRateExpected);
                            }
                            if (typeof data.availableFrom != 'undefined' && data.availableFrom != '-') {
                                $scope.user.availableFrom = new Date(data.availableFrom);
                            }
                            if (typeof data.projectDuration != 'undefined' && data.projectDuration != '-') {
                                $scope.user.projectDuration = parseInt(data.projectDuration);
                            }
                            if (typeof data.preferredLocation != 'undefined' && data.preferredLocation != '-') {
                                data.preferredLocation = JSON.parse(data.preferredLocation);
                                $scope.locations = [];
                                angular.forEach(data.preferredLocation, function (value, key) {
                                    this.push({
                                        address: (typeof value.address != 'undefined') ? value.address : '',
                                        zip: (typeof value.zip != 'undefined') ? value.zip : '',
                                        radius: value.radius
                                    });
                                }, $scope.locations);
                            }
                            if (typeof data.whatsImportant != 'undefined' && data.whatsImportant != '-') {
                                $scope.selectedImportance = data.whatsImportant.split(",");
                            }
                            if (typeof data.remotelyWorkOption != 'undefined' && data.remotelyWorkOption != '-') {
                                $scope.selectedWorkOptions = data.remotelyWorkOption.split(",");
                            }
                        } else if ($scope.pageId == 'preferences') {
                            if (typeof data.facebookId != 'undefined' && data.facebookId != '-') {
                                $scope.user.fbId = data.facebookId;
                            }
                            if (typeof data.skypeId != 'undefined' && data.skypeId != '-') {
                                $scope.user.skypeId = data.skypeId;
                            }
                            if (typeof data.snapchatId != 'undefined' && data.snapchatId != '-') {
                                $scope.user.snapchatId = data.snapchatId;
                            }
                            if (typeof data.githubId != 'undefined' && data.githubId != '-') {
                                $scope.user.githubId = data.githubId;
                            }
                            if (typeof data.linkedinId != 'undefined' && data.linkedinId != '-') {
                                $scope.user.linkedinId = data.linkedinId;
                            }
                            if (typeof data.stackoverflowId != 'undefined' && data.stackoverflowId != '-') {
                                $scope.user.stackoverflowId = data.stackoverflowId;
                            }
                            /*if (typeof data.preferredCommunicationChannel != 'undefined') {
                             data.preferredCommunicationChannel = JSON.parse(data.preferredCommunicationChannel);
                             if (typeof data.preferredCommunicationChannel.email != 'undefined' && data.preferredCommunicationChannel.email != '-') {
                             $scope.user.alternateEmail = data.preferredCommunicationChannel.email;
                             $scope.user.isPreferredAlternateEmail = true;
                             }
                             if (typeof data.preferredCommunicationChannel.phone != 'undefined' && data.preferredCommunicationChannel.phone != '-') {
                             $scope.user.phoneNo = data.preferredCommunicationChannel.phone;
                             $scope.user.isPreferredPhone = true;
                             }
                             if (typeof data.preferredCommunicationChannel.text != 'undefined' && data.preferredCommunicationChannel.text != '-') {
                             $scope.user.candidatetext = data.preferredCommunicationChannel.text;
                             $scope.user.isPreferredText = true;
                             }
                             }*/
                            if (typeof data.alternateEmail != 'undefined' && data.alternateEmail != '-') {
                                $scope.user.alternateEmail = data.alternateEmail;
                            }
                            if (typeof data.candidatetext != 'undefined' && data.candidatetext != '-') {
                                $scope.user.candidatetext = data.candidatetext;
                            }
                            if (typeof data.phoneNo != 'undefined' && data.phoneNo != '-') {
                                $scope.user.phoneNo = data.phoneNo;
                            }
                            if (typeof data.isPreferredAlternateEmail != 'undefined') {
                                $scope.user.isPreferredAlternateEmail = (data.isPreferredAlternateEmail == 'Y') ? true : false;
                            }
                            if (typeof data.isPreferredText != 'undefined') {
                                $scope.user.isPreferredText = (data.isPreferredText == 'Y') ? true : false;
                            }
                            if (typeof data.isPreferredPhone != 'undefined') {
                                $scope.user.isPreferredPhone = (data.isPreferredPhone == 'Y') ? true : false;
                            }
                            if (typeof data.profileImageBase64Str != 'undefined' && data.profileImageBase64Str != '' && data.profileImageBase64Str != '-') {
                                $scope.mainProfileImage = data.profileImageBase64Str;
                            }
                        }
                    }
                } else {
                    var err = 'Something going wrong, Please try again.';
                    if (typeof data.ERROR_MESSAGE != 'undefined') {
                        err = data.ERROR_MESSAGE;
                    }
                    alertService.showAlert('Failure', err);
                }
            },
            function (err) {
                alertService.showAlert('Failure', 'Something going wrong, Please reload the page.');
            }
        );
    }
    /**
     * End
     */

    $scope.logoUrl = $scope.baseUrl + 'index.html';
    if (typeof $rootScope.isUserLogin != 'undefined' && $rootScope.isUserLogin != '') {
        if ($location.absUrl() == $scope.baseUrl || $location.absUrl() == $scope.baseUrl + 'index.html') {
            $window.location.href = $scope.baseUrl + 'dashboard.html';
        }
        $scope.logoUrl = $scope.baseUrl + 'dashboard.html';
        $scope.candidateEmail = webService.getUser();
        $rootScope.candidateName = (webService.getLocalStorage('userName')) ? webService.getLocalStorage('userName') : 'Steve';
        $scope.user.alternateEmail = $scope.candidateEmail;
        $scope.user.isPreferredAlternateEmail = true;
        tmpprofileImage = webService.getLocalStorage('userPhoto');
        if (tmpprofileImage != '' && tmpprofileImage != "-") {
            $rootScope.profileImage = webService.getLocalStorage('userPhoto');
        }
    }
    var params = $location.search();
    skill = params.skill;
    if (skill) {
        $rootScope.skill = skill;
    } else {
        $rootScope.skill = "Java, .NET";
    }

    /**
     * Register new Candidate
     */
    $scope.registerUser = function () {
        //serviceUrl = 'https://ksk935gsh9.execute-api.us-east-1.amazonaws.com/stage/candidate';
        lamdaFunction = "registerCandidate";
        if (!$scope.user.phoneNo) {
            $scope.user.phoneNo = "";
        }
        reqJSON = $scope.user;
        webService.sendPostRequest(lamdaFunction, reqJSON,
            function (response) {
                data = JSON.parse(response.data);
                if (data.RESPONSE_CODE == 'SUCCESS') {
                    $scope.userRegForm.$setPristine();
                    fname = $scope.user.fullName.split(" ");
                    webService.setUser($scope.user.emailId, fname[0]); //Set user as login.
                    $scope.user.alternateEmail = $scope.candidateEmail;
                    $scope.user.isPreferredAlternateEmail = true;
                    //alertService.showAlert('Success', 'Account has been created successfully.');
                    var success = 'Account has been created successfully.';
                    if (typeof data.SUCCESS_MESSAGE != 'undefined') {
                        success = data.SUCCESS_MESSAGE;
                    }
                    alertService.setNotification(success);
                    $window.location.href = $scope.baseUrl + 'edit_profile.html';
                } else if (data.RESPONSE_CODE == 'WARNING') {
                    var warning = 'Email already exists.';
                    if (typeof data.ERROR_MESSAGE != 'undefined') {
                        warning = data.ERROR_MESSAGE;
                    }
                    alertService.setNotification(warning, 'warning');
                    $scope.showNotification();
                } else {
                    var err = 'Something going wrong, Please try again.';
                    if (typeof data.ERROR_MESSAGE != 'undefined') {
                        err = data.ERROR_MESSAGE;
                    }
                    alertService.setNotification(err);
                    $scope.showNotification(err, 'failure');
                    //alertService.showAlert('Failure', err);
                }
            },
            function (err) {
                alertService.showAlert('Failure', 'Something going wrong, Please try again.');
            }
        );
    };

    $scope.addPreferredCommnChannels = function (channel) {
        if (preferredCommnChannels.indexOf(channel) == -1) {
            preferredCommnChannels.push(channel);
        } else {
            preferredCommnChannels.splice(preferredCommnChannels.indexOf(channel), 1);
        }
    }

    $scope.isPreferredCommnChannelSelected = function (channel) {
        return (preferredCommnChannels.indexOf(channel) > -1);
    };

    $scope.addPreferredEmploymentType = function (type) {
        if (preferredEmploymentTypes.indexOf(type) == -1) {
            preferredEmploymentTypes.push(type);
        } else {
            preferredEmploymentTypes.splice(preferredEmploymentTypes.indexOf(type), 1);
        }
    }

    $scope.isPreferredEmploymentType = function (type) {
        return (preferredEmploymentTypes.indexOf(type) > -1);
    };

    /**
     * Make login request.
     */
    $scope.login = function () {
        if (typeof $scope.user.emailId == 'undefined' || $scope.user.emailId == '' || $scope.user.emailId == null) {
            webService.setNotification('Please enter Email.', 'failure');
            $scope.showNotification();
        } else if (typeof $scope.user.password == 'undefined' || $scope.user.password == '' || $scope.user.password == null) {
            webService.setNotification('Please enter Password.', 'failure');
            $scope.showNotification();
        } else {
            data = {
                emailId: $scope.user.emailId,
                password: $scope.user.password,
            }
            webService.requestLogin(JSON.stringify(data),
                function (response) {
                    data = JSON.parse(response.data);
                    if (data.RESPONSE_CODE == 'SUCCESS') {
                        /*var success = 'You have login successfully.';
                         if (typeof data.SUCCESS_MESSAGE != 'undefined') {
                         success = data.SUCCESS_MESSAGE;
                         }
                         alertService.setNotification(success);*/
                          $rootScope.candidateName = (webService.getLocalStorage('userName')) ? webService.getLocalStorage('userName') : 'Steve';
                        $window.location.href = $scope.baseUrl + 'dashboard.html';
                    } else {
                        var err = 'Something going wrong, Please try again.';
                        if (typeof data.ERROR_MESSAGE != 'undefined') {
                            err = data.ERROR_MESSAGE;
                        }
                        //alertService.showAlert('Failure', err);
                        alertService.setNotification(err, 'failure');
                        $scope.showNotification();
                    }
                },
                function (err) {
                    //alertService.showAlert('Failure', 'Something going wrong, Please try again.');
                    alertService.setNotification('Something going wrong, Please try again.', 'failure');
                    $scope.showNotification();
                }
            );
        }
    }

    /**
     * Allow user to logout.
     */
    $scope.logoutMe = function () {
        webService.logOut($scope.baseUrl + 'index.html');
    }

    /**
     * Update candidate information.
     */
    $scope.updateCandidate = function () {
        $scope.user.preferredCommnChanne = preferredCommnChannels.toString();
        $scope.user.preferredEmploymentType = preferredEmploymentTypes.toString();
        if ($scope.user.availableFrom) {
            $scope.user.availableFrom = moment($scope.user.availableFrom).format('MMMM D, YYYY');
        }
        //var serviceUrl = 'https://qh2esojkch.execute-api.us-east-1.amazonaws.com/stage/candidate';
        lamdaFunction = "updateCandidatePref";
        webService.sendPostRequest(lamdaFunction, $scope.user,
            function (response) {
                data = JSON.parse(response.data);
                if (data.RESPONSE_CODE == 'SUCCESS') {
                    var success = 'Information has been Updated Successfully.';
                    if (typeof data.SUCCESS_MESSAGE != 'undefined') {
                        success = data.SUCCESS_MESSAGE;
                    }
                    alertService.showAlert('Success', success);
                } else {
                    var err = 'Something going wrong, Please try again.';
                    if (typeof data.ERROR_MESSAGE != 'undefined') {
                        err = data.ERROR_MESSAGE;
                    }
                    alertService.showAlert('Failure', err);
                }
            },
            function (err) {
                alertService.showAlert('Failure', 'Something going wrong, Please try again.');
            }
        );
    };

    $scope.addEducation = function (education) {
        $scope.profilePageIsDirty = true;
        if ($scope.selectedEducations.indexOf(education) == -1) {
            $scope.selectedEducations = [];
            $scope.selectedEducations.push(education);
        } else {
            $scope.selectedEducations.splice($scope.selectedEducations.indexOf(education), 1);
        }
    }
    $scope.isEducationSelected = function (education) {
        return ($scope.selectedEducations.indexOf(education) > -1);
    };

    $scope.addExperience = function (experience) {
        $scope.profilePageIsDirty = true;
        if ($scope.selectedExperiences.indexOf(experience) == -1) {
            $scope.selectedExperiences = [];
            $scope.selectedExperiences.push(experience);
        } else {
            $scope.selectedExperiences.splice($scope.selectedExperiences.indexOf(experience), 1);
        }
    }
    $scope.isExperienceSelected = function (experience) {
        return ($scope.selectedExperiences.indexOf(experience) > -1);
    };

    $scope.addRoles = function (role) {
        $scope.profilePageIsDirty = true;
        if ($scope.selectedRoles.indexOf(role) == -1) {
            $scope.selectedRoles.push(role);
        } else {
            $scope.selectedRoles.splice($scope.selectedRoles.indexOf(role), 1);
        }
    }
    $scope.isRoleSelected = function (role) {
        return ($scope.selectedRoles.indexOf(role) > -1);
    };

    $scope.addWorkAuthorization = function (work) {
        $scope.jobPreferencePageIsDirty = true;
        if ($scope.selectedWorkAuthorization.indexOf(work) == -1) {
            $scope.workAuthorizationError = false;
            $scope.selectedWorkAuthorization = [];
            $scope.selectedWorkAuthorization.push(work);
        } else {
            $scope.selectedWorkAuthorization.splice($scope.selectedWorkAuthorization.indexOf(work), 1);
        }
    }
    $scope.isWorkAuthorizationSelected = function (work) {
        return ($scope.selectedWorkAuthorization.indexOf(work) > -1);
    };

    $scope.addContractType = function (type) {
        $scope.jobPreferencePageIsDirty = true;
        if ($scope.selectedContractType.indexOf(type) == -1) {
            $scope.preferredContractTypeError = false;
            $scope.selectedContractType.push(type);
        } else {
            $scope.selectedContractType.splice($scope.selectedContractType.indexOf(type), 1);
        }
    }
    $scope.isContractTypeSelected = function (type) {
        return ($scope.selectedContractType.indexOf(type) > -1);
    };

    $scope.addStatus = function (selectedStatus) {
        $scope.jobPreferencePageIsDirty = true;
        if ($scope.selectedStatus.indexOf(selectedStatus) == -1) {
            $scope.statusError = false;
            $scope.selectedStatus = [];
            $scope.selectedStatus.push(selectedStatus);
        } else {
            $scope.selectedStatus.splice($scope.selectedStatus.indexOf(selectedStatus), 1);
        }
    }
    $scope.isStatusSelected = function (selectedStatus) {
        return ($scope.selectedStatus.indexOf(selectedStatus) > -1);
    };

    $scope.addLocation = function () {
        $scope.jobPreferencePageIsDirty = true;
        var address = (typeof $scope.tmpLocation.name != 'undefined') ? $scope.tmpLocation.name : '';
        if (address != '') {
            if (!$scope.locationExists($scope.locations, address)) {
                $scope.locationExistError = false;
                $scope.locations.push({
                    address: (typeof $scope.tmpLocation.name != 'undefined') ? $scope.tmpLocation.name : '',
                    zip: (typeof $scope.tmpLocation.details != 'undefined') ? ((typeof $scope.tmpLocation.details.zip != 'undefined') ? $scope.tmpLocation.details.zip : '') : '',
                    radius: '30 Miles'
                });
                $scope.tmpLocation = '';
            } else {
                $scope.locationExistError = true;
            }
        }
    }
    $scope.removeLocation = function (index) {
        $scope.locations.splice(index, 1);
    };

    $scope.addImportance = function (important) {
        $scope.jobPreferencePageIsDirty = true;
        if ($scope.selectedImportance.indexOf(important) == -1) {
            $scope.whatsImportantError = false;
            $scope.selectedImportance.push(important);
        } else {
            $scope.selectedImportance.splice($scope.selectedImportance.indexOf(important), 1);
        }
    }
    $scope.isImportanceSelected = function (important) {
        return ($scope.selectedImportance.indexOf(important) > -1);
    };

    $scope.addWorkOptions = function (workOption) {
        $scope.jobPreferencePageIsDirty = true;
        if ($scope.selectedWorkOptions.indexOf(workOption) == -1) {
            $scope.workOptionError = false;
            $scope.selectedWorkOptions = [];
            $scope.selectedWorkOptions.push(workOption);
        } else {
            $scope.selectedWorkOptions.splice($scope.selectedWorkOptions.indexOf(workOption), 1);
        }
    }
    $scope.isWorkOptionSelected = function (workOption) {
        return ($scope.selectedWorkOptions.indexOf(workOption) > -1);
    };

    /**
     * Manage Next and Previous Button on Edit profile page.
     * @param action
     * @returns {boolean}
     */
    $scope.changeView = function (action) {
        if (typeof action == 'undefined') {
            return false;
        }
        if (action == 'next') {
            if ($scope.editProfilePage1) {
                $scope.updateCandidateProfilePage1();
            } else if ($scope.editProfilePage2) {
                //$scope.updateCandidateProfilePage2();
            } else if ($scope.editProfilePage3) {
                //$scope.updateCandidateSocialProfile();
            }
        } else if (action == 'previous') {
            if ($scope.editProfilePage3) {
                $scope.showJobPreferencePage();
            } else if ($scope.editProfilePage2) {
                $scope.showProfilePage();
            }
        }
        $location.hash('topPosition');
        $anchorScroll();
        return false;
    };

    /**
     * Update candidate Profile.
     */
    $scope.updateCandidateProfilePage1 = function () {
        $scope.profilePageIsDirty = false;
        var data = {
            emailId: webService.getUser(),
            yearsOfExp: $scope.selectedExperiences.toString(),
            coreSkills: $scope.selectedSkills,
            coreRoles: $scope.selectedRoles.toString(),
            education: $scope.selectedEducations.toString()
        };
        /*if (data.coreRoles == '' && data.coreSkills == '' && data.education == '' && data.yearsOfExp == '') {
         $scope.showJobPreferencePage();
         } else {
         //Make call
         }*/
        //var serviceUrl = 'https://h92ip3dg77.execute-api.us-east-1.amazonaws.com/stage/candidate';
        lamdaFunction = "updateCandidateProfile";
        webService.sendPostRequest(lamdaFunction, data,
            function (response) {
                data = JSON.parse(response.data);
                if (data.RESPONSE_CODE == 'SUCCESS') {
                    var success = 'Information has been Updated Successfully.';
                    if (typeof data.SUCCESS_MESSAGE != 'undefined') {
                        success = data.SUCCESS_MESSAGE;
                    }
                    alertService.setNotification(success);
                    //alertService.showAlert('Success', success);
                    if (typeof $scope.pageId != 'undefined') {
                        $window.location.href = $scope.baseUrl + 'dashboard.html';
                    } else {
                        $scope.showJobPreferencePage();
                        $scope.showNotification();
                        $location.hash('topPosition');
                        $anchorScroll();
                    }
                } else {
                    var err = 'Something going wrong, Please try again.';
                    if (typeof data.ERROR_MESSAGE != 'undefined') {
                        err = data.ERROR_MESSAGE;
                    }
                    alertService.setNotification(err, 'failure');
                    $scope.showNotification();
                    //alertService.showAlert('Failure', err);
                }
            },
            function (err) {
                //alertService.showAlert('Failure', 'Something going wrong, Please try again.');
                alertService.setNotification('Something going wrong, Please try again.', 'failure');
                $scope.showNotification();
            }
        );
    };

    /**
     * Format Location array to send on server.
     * @returns {Array}
     */
    function extractLocation() {
        locations = $scope.locations;
        var locate = [];
        angular.forEach(locations, function (value, key) {
            if (typeof value.location != 'undefined' && value.location != "") {
                //if (typeof value.location.details != 'undefined' && value.location.details != "") {
                this.push({
                    //address: ((typeof value.location.details != 'undefined') ? ((typeof value.location.details.city != 'undefined') ? value.location.details.city : '') : '') + ', ' + ((typeof value.location.details != 'undefined') ? ((typeof value.location.details.state != 'undefined') ? value.location.details.state : '') : ''),
                    address: (typeof value.location.name != 'undefined') ? value.location.name : '',
                    zip: (typeof value.location.details != 'undefined') ? ((typeof value.location.details.zip != 'undefined') ? value.location.details.zip : '') : '',
                    radius: value.nearby
                });
                //}
            }
        }, locate);
        return locate;
    }

    /**
     * Navigate to login page.
     */
    $scope.goToSignIn = function () {
        $window.location.href = $scope.baseUrl + 'index.html';
    };

    /**
     * Navigate to Signup page.
     */
    $scope.goToSignUp = function () {
        $window.location.href = $scope.baseUrl + 'signup.html';
    };

    /**
     * Navigate to forgot password page.
     */
    $scope.goToForgotPassword = function () {
        $window.location.href = $scope.baseUrl + 'forgot_password.html';
    };

    /**
     * Upload resume file on server.
     */
    $scope.uploadProfilePic = function (event) {
        var fileReader = new FileReader();
        fileReader.onload = function (event) {
            $scope.$apply(function () {
                $scope.mainProfileImage = event.target.result;
            })
            var data = {
                fileName: event.target.fileName,
                base64String: event.target.result,
                candidateId: event.target.candidateEmail
            };
            $scope.candidateSocialForm.$setPristine();
            //var serviceUrl = 'https://6rebtx75c1.execute-api.us-east-1.amazonaws.com/stage/candidate';
            lamdaFunction = "uploadCandidateProfileImageToS3";
            webService.sendPostRequest(lamdaFunction, data,
                function (response) {
                    data = JSON.parse(response.data);
                    data = data.candidatePref;
                    tmpProfileImage = data.profileImageBase64Str;
                    webService.setLocalStorage('userPhoto', tmpProfileImage);
                    $rootScope.profileImage = tmpProfileImage;
                    alertService.setNotification('Your Profile picture has been uploaded successfully.');
                    $scope.showNotification();
                },
                function (error) {
                    $scope.mainProfileImage = $scope.baseUrl + '../images/default-user.png';
                    alertService.setNotification('Unable to upload Profile picture.', 'failure');
                    $scope.showNotification();
                    //alertService.showAlert('Failure', 'Unable to upload Profile picture.');
                }
            );
        };

        fileReader.candidateEmail = $scope.candidateEmail;
        if (typeof event.target.files[0] != 'undefined') {
            fileType = event.target.files[0].type;
            if ($scope.allowedFileTypesForProfilePicture.indexOf(fileType) > -1) {
                fileReader.fileName = event.target.files[0].name;
                fileReader.readAsDataURL(event.target.files[0]);
            } else {
                alertService.showAlert('Failure', 'Profile picture must be image.');
            }
        } else {
            $scope.mainProfileImage = '';
        }
    };

    /**
     * Send Password reset link to user's email to reset password.
     */
    $scope.forgotPassword = function () {
        if (typeof $scope.user.emailId == 'undefined' || $scope.user.emailId == '' || $scope.user.emailId == null) {
            alertService.showAlert('Error', 'please enter Email.');
        } else {
            var data = {emailId: $scope.user.emailId}
            //var serviceUrl = 'https://3hwtxfz03c.execute-api.us-east-1.amazonaws.com/stage/candidate';
            lamdaFunction = "forgotPasswordCandidate";
            webService.sendPostRequest(lamdaFunction, data,
                function (response) {
                    data = JSON.parse(response.data);
                    if (data.RESPONSE_CODE == 'SUCCESS') {
                        var msg = 'Your password is reset and new password sent to your email.';
                        if (typeof data.SUCCESS_MESSAGE != 'undefined') {
                            msg = data.SUCCESS_MESSAGE;
                        }
                        alertService.showAlert('Success', msg);
                        $window.location.href = $scope.baseUrl;
                    } else {
                        var err = 'Something going wrong, Please try again.';
                        if (typeof data.ERROR_MESSAGE != 'undefined') {
                            err = data.ERROR_MESSAGE;
                        }
                        alertService.showAlert('Failure', err);
                    }
                },
                function (err) {
                    alertService.showAlert('Failure', 'Something going wrong, Please try again.');
                }
            );
        }
    }

    /**
     * Add / Edit Candidate job Preferences.
     */
    $scope.submitCandidateJobForm = function () {
        $scope.jobPreferencePageIsDirty = false;
        var data = {
            emailId: webService.getUser(),
            jobMatchPercentThreshold: $scope.user.skillMatchPercent,
            workAuthorization: $scope.selectedWorkAuthorization.toString(),
            preferredContractType: $scope.selectedContractType.toString(),
            minHourlyRateExpected: $scope.user.hourRate,
            preferredLocation: $scope.locations,
            candidateStatus: $scope.selectedStatus.toString(),
            whatsImportant: $scope.selectedImportance.toString(),
            workOption: $scope.selectedWorkOptions.toString(),
            availableFrom: (($scope.user.availableFrom != null) ? moment($scope.user.availableFrom).format('MMMM D, YYYY') : ''),
            projectDuration: ($scope.user.projectDuration == null) ? "" : $scope.user.projectDuration
        };
        // if (validateJobForm(data)) {
        if (true) {
            //var serviceUrl = 'https://arta2vtdt9.execute-api.us-east-1.amazonaws.com/stage/candidate';
            lamdaFunction = "updateCandidateJobPreference";
            webService.sendPostRequest(lamdaFunction, data,
                function (response) {
                    data = JSON.parse(response.data);
                    if (data.RESPONSE_CODE == 'SUCCESS') {
                        var success = 'Information has been Updated Successfully.';
                        if (typeof data.SUCCESS_MESSAGE != 'undefined') {
                            success = data.SUCCESS_MESSAGE;
                        }
                        //alertService.showAlert('Success', success);
                        alertService.setNotification(success);
                        if (typeof $scope.pageId != 'undefined') {
                            $window.location.href = $scope.baseUrl + 'dashboard.html';
                        } else {
                            $scope.showNotification();
                            $scope.showSocialPreferencePage();
                            $location.hash('topPosition');
                            $anchorScroll();
                        }
                    } else {
                        var err = 'Something going wrong, Please try again.';
                        if (typeof data.ERROR_MESSAGE != 'undefined') {
                            err = data.ERROR_MESSAGE;
                        }
                        alertService.setNotification(err, 'failure');
                        $scope.showNotification();
                        //alertService.showAlert('Failure', err);
                    }
                },
                function (err) {
                    //alertService.showAlert('Failure', 'Something going wrong, Please try again.');
                    alertService.setNotification('Something going wrong, Please try again.', 'failure');
                    $scope.showNotification();
                }
            );
        }
    };

    /**
     * Add / Edit Candidate Social Media Profile.
     */
    $scope.updateCandidateSocialProfile = function () {
        $scope.socialPageIsDirty = false;
        var data = {
            emailId: webService.getUser(),
            facebookId: $scope.user.fbId,
            skypeId: $scope.user.skypeId,
            snapchatId: $scope.user.snapchatId,
            githubId: $scope.user.githubId,
            linkedinId: $scope.user.linkedinId,
            stackoverflowId: $scope.user.stackoverflowId,
            alternateEmail: $scope.user.alternateEmail,
            candidatetext: $scope.user.candidatetext,
            phoneNo: $scope.user.phoneNo,
            isPreferredAlternateEmail: ($scope.user.isPreferredAlternateEmail) ? 'Y' : 'N',
            isPreferredText: ($scope.user.isPreferredText) ? 'Y' : 'N',
            isPreferredPhone: ($scope.user.isPreferredPhone) ? 'Y' : 'N'
        };
        //var serviceUrl = 'https://4q18it8jph.execute-api.us-east-1.amazonaws.com/stage/candidate';
        lamdaFunction = "updateCandidateSocialProfile";
        webService.sendPostRequest(lamdaFunction,data,
            function (response) {
                data = JSON.parse(response.data);
                if (data.RESPONSE_CODE == 'SUCCESS') {
                    $scope.candidateSocialForm.$setPristine();
                    var success = 'Information has been Updated Successfully.';
                    if (typeof data.SUCCESS_MESSAGE != 'undefined') {
                        success = data.SUCCESS_MESSAGE;
                    }
                    //alertService.showAlert('Success', success);
                    alertService.setNotification(success);
                    if (typeof $scope.pageId != 'undefined') {
                        $window.location.href = $scope.baseUrl + 'dashboard.html';
                    } else {
                        $scope.showNotification();
                        $scope.showDashboard();
                        //$scope.showVideoPreferencePage();
                        //$location.hash('topPosition');
                        //$anchorScroll();
                    }
                } else {
                    var err = 'Something going wrong, Please try again.';
                    if (typeof data.ERROR_MESSAGE != 'undefined') {
                        err = data.ERROR_MESSAGE;
                    }
                    //alertService.showAlert('Failure', err);
                    alertService.setNotification(err, 'failure');
                    $scope.showNotification();
                }
            },
            function (err) {
                //alertService.showAlert('Failure', 'Something going wrong, Please try again.');
                alertService.setNotification('Something going wrong, Please try again.', 'failure');
                $scope.showNotification();
            }
        );
    };

    /**
     * Validate candidate job preference form
     * @param data
     * @returns {boolean}
     */
    function validateJobForm(data) {
        $scope.jobMatchPercentThresholdError = false;
        $scope.workAuthorizationError = false;
        $scope.preferredContractTypeError = false;
        $scope.minHourlyRateExpectedError = false;
        $scope.statusError = false;
        $scope.whatsImportantError = false;
        $scope.workOptionError = false;

        var isValid = true;
        if (parseInt(data.jobMatchPercentThreshold) <= 10) {
            $scope.jobMatchPercentThresholdError = true;
            isValid = false;
        }
        if (data.workAuthorization == '') {
            $scope.workAuthorizationError = true;
            isValid = false;
        }
        if (data.preferredContractType == '') {
            $scope.preferredContractTypeError = true;
            isValid = false;
        }
        if (parseInt(data.minHourlyRateExpected) <= 10) {
            $scope.minHourlyRateExpectedError = true;
            isValid = false;
        }
        if (data.status == '') {
            $scope.statusError = true;
            isValid = false;
        }
        if (data.whatsImportant == '') {
            $scope.whatsImportantError = true;
            isValid = false;
        }
        if (data.workOption == '') {
            $scope.workOptionError = true;
            isValid = false;
        }
        return isValid;
    }

    /**
     * Display Popup for Forgot password.
     * @param ev
     */
    $scope.showTabDialog = function (ev) {
        $mdDialog.show({
            controller: dialogController,
            templateUrl: 'forgot_password.html',
            parent: angular.element(document.body),
            targetEvent: ev,
            escapeToClose: false,
            clickOutsideToClose: false
        })
            .then(function (answer) {
                //TODO: Handle this call if need.
            }, function () {
                //$scope.status = 'You cancelled the dialog.';
                //TODO: Handle this call if need.
            });
    };

    /**
     * Handle Forgot password popup events.
     * @param $rootScope
     * @param $scope
     * @param $mdDialog
     * @param webService
     */
    function dialogController($rootScope, $scope, $mdDialog, webService) {
        $scope.user = {
            emailId: ''
        };
        $scope.hide = function () {
            $mdDialog.hide();
        };
        $scope.cancel = function () {
            $mdDialog.cancel();
        };
        $scope.answer = function () {
            if (typeof $scope.user.emailId == 'undefined' || $scope.user.emailId == '' || $scope.user.emailId == null) {
                alertService.showAlert('Error', 'please enter Email.');
            } else {
                var data = {emailId: $scope.user.emailId}
                //var serviceUrl = 'https://3hwtxfz03c.execute-api.us-east-1.amazonaws.com/stage/candidate';
                lamdaFunction = "forgotPasswordCandidate";
                webService.sendPostRequest(lamdaFunction, data,
                    function (response) {
                        data = JSON.parse(response.data);
                        if (data.RESPONSE_CODE == 'SUCCESS') {
                            var msg = 'Your password is reset and new password sent to your email.';
                            if (typeof data.SUCCESS_MESSAGE != 'undefined') {
                                msg = data.SUCCESS_MESSAGE;
                            }
                            alertService.showAlert('Success', msg);
                        } else {
                            var err = 'Something going wrong, Please try again.';
                            if (typeof data.ERROR_MESSAGE != 'undefined') {
                                err = data.ERROR_MESSAGE;
                            }
                            alertService.showAlert('Failure', err);
                        }
                    },
                    function (err) {
                        alertService.showAlert('Failure', 'Something going wrong, Please try again.');
                    }
                );
            }
        };
    }

    /**
     * Display Popup for Change password.
     * @param ev
     */
    $scope.showChangePasswordDialog = function (ev, candidateName, candidateEmailId) {
        $scope.candidateFirstName = candidateName;
        $scope.candidateEmailId = candidateEmailId;
        $mdDialog.show({
            controller: changePasswordController,
            templateUrl: 'change_password.html',
            parent: angular.element(document.body),
            targetEvent: ev,
            escapeToClose: false,
            clickOutsideToClose: false,
            locals: {
                candidateEmailId: $scope.candidateEmailId,
                firstName: $scope.candidateFirstName
            }
        })
            .then(function (answer) {
                //TODO: Handle this call if need.
            }, function () {
                //$scope.status = 'You cancelled the dialog.';
                //TODO: Handle this call if need.
            });
    };

    /**
     * Handle Change password popup events.
     * @param $rootScope
     * @param $scope
     * @param $mdDialog
     * @param webService
     * @param candidateEmailId
     * @param firstName
     */
    function changePasswordController($rootScope, $scope, $mdDialog, webService, candidateEmailId, firstName) {
        $scope.candidateFirstName = firstName;
        $scope.changePasswordInfo = {
            emailId: candidateEmailId,
            oldPassword: '',
            newPassword: '',
            confirmPassword: ''
        };
        $scope.cancel = function () {
            $mdDialog.cancel();
        };
        $scope.changePassword = function () {
            if (typeof $scope.changePasswordInfo.emailId == 'undefined' || $scope.changePasswordInfo.emailId == '' || $scope.changePasswordInfo.emailId == null) {
                alertService.showAlert('Error', 'please enter Email.');
            } else {
                //var serviceUrl = 'https://8jgy8dh8yg.execute-api.us-east-1.amazonaws.com/stage/candidate';
                lamdaFunction = "resetCandidatePassword";
                webService.sendPostRequest(lamdaFunction, $scope.changePasswordInfo,
                    function (response) {
                        data = JSON.parse(response.data);
                        if (data.RESPONSE_CODE == 'SUCCESS') {
                            var msg = 'Your password is changed successfully.';
                            if (typeof data.SUCCESS_MESSAGE != 'undefined') {
                                msg = data.SUCCESS_MESSAGE;
                            }
                            alertService.showAlert('Success', msg);
                        } else {
                            var err = 'Something going wrong, Please try again.';
                            if (typeof data.ERROR_MESSAGE != 'undefined') {
                                err = data.ERROR_MESSAGE;
                            }
                            alertService.showAlert('Failure', err);
                        }
                    },
                    function (err) {
                        alertService.showAlert('Failure', 'Something going wrong, Please try again.');
                    }
                );
            }
        };
    }

    /**
     * Skip button
     */
    $scope.skipNext = function () {
        if ($scope.editProfilePage1) {
            $scope.profilePageIsDirty = false;
            $scope.showJobPreferencePage();
        } else if ($scope.editProfilePage2) {
            $scope.showSocialPreferencePage();
        } else if ($scope.editProfilePage3) {
            $scope.showVideoPreferencePage();
        }
        $location.hash('topPosition');
        $anchorScroll();
    };

    /**
     * Move page when click on three dots on top of the pages.
     * @param currentPage
     */
    $scope.moveNext = function (currentPage) {
        if (currentPage == 1) {
            $scope.showProfilePage();
        } else if (currentPage == 2) {
            $scope.showJobPreferencePage();
        } else if (currentPage == 3) {
            $scope.showSocialPreferencePage();
        }
    };

    $scope.changeEmail = function () {
        if ($scope.user.alternateEmail != '') {
            $scope.user.isPreferredAlternateEmail = true;
        } else {
            $scope.user.isPreferredAlternateEmail = false;
        }
    };

    $scope.changePhone = function () {
        if ($scope.user.phoneNo != '') {
            $scope.user.isPreferredPhone = true;
        } else {
            $scope.user.isPreferredPhone = false;
        }
    };

    $scope.changeText = function () {
        if ($scope.user.candidatetext != '') {
            $scope.user.isPreferredText = true;
        } else {
            $scope.user.isPreferredText = false;
        }
    };

    $scope.showFileSelectPopup = function () {
        if ($scope.showFilePopup) {
            $scope.showFilePopup = false;
        } else {
            $scope.showFilePopup = true;
        }
    };

    /**
     * Event Binding to show Resume file name from UploadResume controller.
     */
    $rootScope.$on("showResumeFileName", function (e, resumeFileName) {
        $scope.fileName = resumeFileName.name;
    });

    /**
     * Display Popup for Resume Upload.
     * @param ev
     */
    $scope.showUploadResumeDialog = function (ev) {
        $mdDialog.show({
            controller: uploadResumeController,
            templateUrl: 'app/templates/upload_resume_popup.html',
            parent: angular.element(document.body),
            targetEvent: ev,
            escapeToClose: true,
            clickOutsideToClose: true
        }).then(function (answer) {
            //TODO: Handle this call if need.
        }, function () {
            //$scope.status = 'You cancelled the dialog.';
            //TODO: Handle this call if need.
        });
    };

    /**
     * Handle Resume upload popup events.
     * @param $rootScope
     * @param $scope
     * @param $mdDialog
     * @param webService
     */
    function uploadResumeController($rootScope, $scope, $mdDialog, webService) {
        $scope.allowedFileTypesForResume = ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
        $scope.cancel = function () {
            $mdDialog.cancel();
        };
        /**
         * Upload resume file on server.
         */
        $scope.uploadFile = function (event) {
            var fileReader = new FileReader();
            fileReader.onload = function (event) {
                var uri = event.target.result;
                $scope.imageStrings = uri;
                $rootScope.$emit("showResumeFileName", {name: event.target.fileName});
                var data = {
                    fileName: event.target.fileName,
                    base64String: event.target.result,
                    candidateId: event.target.candidateEmail
                };

                //var serviceUrl = 'https://k7ip5fp0ba.execute-api.us-east-1.amazonaws.com/stage/candidate';
                lamdaFunction = "uploadCandidateResumeToS3";
                webService.sendPostRequest(lamdaFunction, data,
                    function (response) {
                        if (response.data == 'success') {
                            alertService.showAlert('Success', 'Your resume has been uploaded successfully.');
                        } else {
                            alertService.showAlert('Failure', 'Unable to upload Resume file.');
                        }
                    },
                    function () {
                        alertService.showAlert('Failure', 'Unable to upload Resume file.');
                    }
                );
            };
            fileReader.candidateEmail = webService.getLocalStorage('user');
            if (typeof event.target.files[0] != 'undefined') {
                fileType = event.target.files[0].type;
                if ($scope.allowedFileTypesForResume.indexOf(fileType) > -1) {
                    fileReader.fileName = event.target.files[0].name;
                    $scope.fileName = event.target.files[0].name;
                    fileReader.readAsDataURL(event.target.files[0]);
                } else {
                    alertService.showAlert('Failure', 'Resume file must be pdf or word document.');
                }
            } else {
                $scope.fileName = '';
            }
        };
    }

    /**
     * Create filter function for a query string
     */
    $scope.createFilterFor = function (query) {
        var lowercaseQuery = angular.lowercase(query);
        return function filterFn(skill) {
            return (angular.lowercase(skill.skill).indexOf(lowercaseQuery) === 0);
        };

    }

    $scope.querySearch = function (query) {
        var results = query ? $scope.allSkills.filter($scope.createFilterFor(query)) : $scope.allSkills;
        return results;
    }

    $scope.selectedSkillChange = function (skill) {
        $scope.profilePageIsDirty = true;
        if (typeof skill.id != 'undefined' && skill.id != '' && skill.id != 0) {
            $scope.selectedSkills.push(skill);
            $scope.refreshSkills($scope.selectedSkill);
        }
        //$scope.selectedSkill = ' ';
        $scope.searchText = '';
    };
    $scope.removeSkill = function (index) {
        $scope.selectedSkills.splice(index, 1);
    };

    /**
     * Check if location is exist in user selection or not.
     * @param data
     * @param location
     * @returns {boolean}
     */
    $scope.locationExists = function (data, location) {
        var hasMatch = false;
        for (var index = 0; index < data.length; ++index) {
            var locate = data[index];
            if (locate.address == location) {
                hasMatch = true;
                break;
            }
        }
        return hasMatch;
    };

    /**
     * Remove skill from list after user selection.
     * @param skill
     * @returns {boolean}
     */
    $scope.refreshSkills = function (skill) {
        var hasMatch = false;
        var data = $scope.allSkills;
        for (var index = 0; index < data.length; ++index) {
            var locate = data[index];
            if (locate.skill == skill.skill) {
                $scope.allSkills.splice(index, 1);
                break;
            }
        }
        return hasMatch;
    };
}]);