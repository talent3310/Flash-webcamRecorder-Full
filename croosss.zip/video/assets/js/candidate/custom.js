/*$(document).ready(function () {
 $("body").delegate("#pushmenu", "click", function () {
 $(".navigationbar__navigation").toggle(300);
 });
 $("body").delegate(".navigationbar__link", "click", function () {
 if ($(this).parent().find('ul').length <= 0) {
 $(".navigationbar__navigation").slideUp(300);
 } else {
 if ($(".navigationbar__dropdown").css('display') != 'none') {
 $(".navigationbar__dropdown").slideUp(300);
 }
 if ($(this).parent().find(".navigationbar__dropdown").css('display') == 'none') {
 $(this).parent().find(".navigationbar__dropdown").slideDown(300);
 }
 else {
 $(this).parent().find(".navigationbar__dropdown").slideUp(300);
 }
 }
 });
 });
 $(document).mouseup(function(e) {
 var $container = $(".navigationbar__navigation");

 // if the target of the click isn't the container nor a descendant of the container
 if (!$container.is(e.target) && $container.has(e.target).length === 0) {
 $container.hide();
 }
 });
 $(window).on('load', function () {
 //scaleWidth();
 });
 $(window).on('resize', function () {
 //scaleWidth();
 });
 function scaleWidth() {
 var width = $(window).width();
 var height = $(window).height();
 $(".sidenav").css("width", width);
 $(".sidenav").css("height", height - 70);
 $("#MainMenu").css("left", "-" + width + "px");
 $("#SubMenu").css("left", "+" + width + "px");
 $("body").delegate("#pushmenu", "click", function () {
 $("#MainMenu").show();
 $(this).hide();
 $('.navigationbar').css('position', 'fixed');
 $('.navigationbar').css('width', '100%');
 $("#MainMenu").animate({"left": "+=" + width + "px"}, "fast");
 });
 $("body").delegate("#MainMenu .close_menu", "click", function () {
 $("#MainMenu").animate({"left": "-=" + width + "px"}, "fast");
 $('#pushmenu').show();
 $('.navigationbar').removeAttr('style');
 });
 $("body").delegate(".submenu", "click", function () {
 $("#SubMenu").show();
 $("#MainMenu").animate({"left": "-=" + width + "px"}, "fast");
 $("#SubMenu").animate({"left": "0px"}, "fast");
 });
 $("body").delegate(".has-popup", "click", function () {
 $("#MainMenu").animate({"left": "-=" + width + "px"}, "fast");
 $('.navigationbar').removeAttr('style');
 $('#pushmenu').show();
 });
 $("body").delegate("#SubMenu .close_submenu", "click", function () {
 $("#SubMenu").animate({"left": "+=" + width + "px"}, "fast");
 $('.navigationbar').removeAttr('style');
 $('#pushmenu').show();
 });
 $("body").delegate("#SubMenu .back_mainmenu", "click", function () {
 $("#SubMenu").animate({"left": "+=" + width + "px"}, "fast");
 $("#MainMenu").animate({"left": "0px"}, "fast");
 });
 }
 $(window).on('load', function () {
 //scaleWidth();
 });
 $(window).on('resize', function () {
 //scaleWidth();
 });
 function scaleWidth() {
 var width = $(window).width();
 var height = $(window).height();
 $(".sidenav").css("width", width);
 $(".sidenav").css("height", height - 70);
 $("#MainMenu").css("left", "-" + width + "px");
 $("#SubMenu").css("left", "+" + width + "px");
 $("body").delegate("#pushmenu", "click", function () {
 $("#MainMenu").show();
 $(this).hide();
 $('.navigationbar').css('position', 'fixed');
 $('.navigationbar').css('width', '100%');
 $("#MainMenu").animate({"left": "+=" + width + "px"}, "fast");
 });
 $("body").delegate("#MainMenu .close_menu", "click", function () {
 $("#MainMenu").animate({"left": "-=" + width + "px"}, "fast");
 $('#pushmenu').show();
 $('.navigationbar').removeAttr('style');
 });
 $("body").delegate(".submenu", "click", function () {
 $("#SubMenu").show();
 $("#MainMenu").animate({"left": "-=" + width + "px"}, "fast");
 $("#SubMenu").animate({"left": "0px"}, "fast");
 });
 $("body").delegate(".has-popup", "click", function () {
 $("#MainMenu").animate({"left": "-=" + width + "px"}, "fast");
 $('.navigationbar').removeAttr('style');
 $('#pushmenu').show();
 });
 $("body").delegate("#SubMenu .close_submenu", "click", function () {
 $("#SubMenu").animate({"left": "+=" + width + "px"}, "fast");
 $('.navigationbar').removeAttr('style');
 $('#pushmenu').show();
 });
 $("body").delegate("#SubMenu .back_mainmenu", "click", function () {
 $("#SubMenu").animate({"left": "+=" + width + "px"}, "fast");
 $("#MainMenu").animate({"left": "0px"}, "fast");
 });
 }*/

$(document).mouseup(function (e) {
    var container = $(".navigationbar__navigation");
    var checkbox = $(".navigationbar__toggle__helper");
    // if the target of the click isn't the container nor a descendant of the container
    if (!container.is(e.target) && container.has(e.target).length === 0 && !checkbox.is(e.target)) {
        $(".navigationbar__toggle__helper").prop('checked', false);
        $(".navigationbar__dropdown").hide();
    }
});
$(document).ready(function () {
    $("body").delegate(".navigationbar__link", "click", function () {
        if ($(this).parent().find('ul').length <= 0) {
            $(".navigationbar__toggle__helper").prop('checked', false);
        } else {
            if ($(".navigationbar__dropdown").css('display') != 'none') {
                $(".navigationbar__dropdown").slideUp(300);
            }
            if ($(this).parent().find(".navigationbar__dropdown").css('display') == 'none') {
                $(this).parent().find(".navigationbar__dropdown").slideDown(300);
            }
            else {
                $(this).parent().find(".navigationbar__dropdown").slideUp(300);
            }
        }
    });
});
