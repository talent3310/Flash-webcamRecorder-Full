
candidateAPP.service('alertService', [ function () {

    this.getUserObject = function(){
        
    };
    
}]);